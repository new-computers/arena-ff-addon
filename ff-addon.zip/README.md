## Add to Are.na / Firefox Add-on

<img src="/img/preview.png" width="1000">

### Contributing

PR's welcome! See [CONTRIBUTING](CONTRIBUTING.md).
